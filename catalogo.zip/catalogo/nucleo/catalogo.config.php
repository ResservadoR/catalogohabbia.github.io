<?php

    /* BASE DE DATOS */
    $host = "localhost";
    $user = "root";
    $password = "";
    $db = "catalogo";

    /* CONFIGURACIÓN WEB */
    $config['nameHotel'] = "Habbia";

?>