<?php include_once 'nucleo/catalogo.config.php'; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo <?php echo $config['nameHotel']; ?></title>

    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Yusei+Magic&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>

    <div class="titulo">
        <h1>CATÁLOGO <?php echo strtoupper($config['nameHotel']); ?></h1>
    </div>
        <hr>
    <div class="contenedor">
        <div class="categorias">
            <a href="#">
                <div class="caja">
                    <h3>RARES</h3>
                    <img src="assets/img/rares.gif" class="rare">
                </div>
            </a>
            <a href="#">
                <div class="caja">
                    <h3>LTD's</h3>
                    <img src="assets/img/ltds.gif" class="ltd">
                </div>
            </a>
            <a href="#">
                <div class="caja">
                    <h3>ULTRAS</h3>
                    <img src="assets/img//ultra.gif" class="ultra">
                </div>
            </a>
            <a href="#">
                <div class="caja">
                    <h3>MEGAS</h3>
                    <img src="assets/img/megas.gif" class="mega">
                </div>
            </a>
        </div>

        <div class="economia">
            <h1>Monedas</h1>
            <div class="caja_economia">
                <div class="contenedor_moneda">
                    <img src="assets/img/th.gif">

                    <div class="info-th"><p>El th es el th mi prro</p></div>
                </div>
                <h6>Thrones</h6>
            </div>
            <div class="caja_economia">
                <div class="contenedor_moneda"></div>
                <h6>Diamantes</h6>
            </div>
            <div class="caja_economia">
                <div class="contenedor_moneda"></div>
                <h6>Usd</h6>
            </div>

            <h1>Últimos cambios</h1>
            <div class="caja_rares">
                <div class="contenedor_rares"></div>
                <h6>RARE</h6>
                <p>Ventolera Amarilla</p>
            </div>
            <div class="caja_rares">
                <div class="contenedor_rares"></div>
                <h6>LTD</h6>
                <p>Heladera Ocre</p>
            </div>
            <div class="caja_rares">
                <div class="contenedor_rares"></div>
                <h6>ULTRA</h6>
                <p>Dragon Rojo</p>
            </div>
            <div class="caja_rares">
                <div class="contenedor_rares"></div>
                <h6>MEGA</h6>
                <p>Aloe Vera</p>
            </div>
        </div>

        <div class="news">
            <div class="caja_news">
                <div class="contenedor_news">
                    <h1>Actualizaciones</h1>
                </div>
            </div>
            <div class="caja_news">
                <div class="contenedor_news">
                    <h1>Novedades</h1>
                </div>
            </div>
            <div class="caja_news_ltd">
                <div class="contenedor_news_ltd">
                    <h1></h1>
                </div>
            </div>
        </div>
        
        <div class="informacion">
            <p>Aquí puedes ver los precios actualizados de los rares, ltds, ultras y megas del hotel. Si no encuentras algún precio puedes comunicarte con nosotros <strong><a href="https://www.facebook.com/Habbia.IN/" target="_blank">AQUÍ</a></strong>. 
            Algo muy importante que debes saber, es que habbia no define los precios, los precios los definen los usuarios.</p>
        </div>
    </div>

    <hr>
    <footer>
        <div class="contenedor_footer">
            <div class="logo"><img src="assets/img/logo.png"></div>
            <h1>© Habbia 2021</h1>
            <div class="contenedor_empaquetado"><img src="assets/img/diseño.png" class="diseño"><p>Diseñado por: Resservado y SteepMaster</p></div>
            <div class="contenedor_empaquetado"><img src="assets/img/programado.png" class="programacion"><p>Programado por: Resservado</p></div>
        </div>
    </footer>
</body>
</html>